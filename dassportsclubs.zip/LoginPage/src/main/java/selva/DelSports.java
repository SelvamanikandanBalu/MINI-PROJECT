package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DelSports
 */
public class DelSports extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sports=request.getParameter("sports");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			String sql = "delete from sports where sports_id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, sports);
			ps.executeUpdate();
			ps.close();
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data removed');");
			out.println("window.location.href='sports.jsp';");
			out.println("</script>");
			con.close();		
		}catch(Exception e) {
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data not removed: the given value may does not exist');");
			out.println("window.location.href='sports.jsp';");
			out.println("</script>");
		}
	}

}
