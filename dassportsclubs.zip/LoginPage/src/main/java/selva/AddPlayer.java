package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddPlayer
 */
public class AddPlayer extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String playerid=request.getParameter("playerid");
		String name=request.getParameter("name");
		String sportname=request.getParameter("sportname");
		String gender=request.getParameter("gender");
		String address=request.getParameter("address");
		String contact=request.getParameter("contact");
		String fee=request.getParameter("fee");
		String feestat=request.getParameter("feestat");
		String dob=request.getParameter("dob");
		String join=request.getParameter("join");
		String sportsid=request.getParameter("sportsid");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			String sql = "insert into players values(?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, playerid);
			ps.setString(2, name);
			ps.setString(3, sportname);
			ps.setString(4, gender);
			ps.setString(5, address);
			ps.setString(6, contact);
			ps.setString(7, fee);
			ps.setString(8, feestat);
			ps.setString(9, dob);
			ps.setString(10, join);
			ps.setString(11, sportsid);
			ps.executeUpdate();
			ps.close();
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data inserted in your database');");
			out.println("window.location.href='players.jsp';");
			out.println("</script>");
			con.close();
			}
		catch(Exception e) {
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data not inserted: player id may exist , fee and contact should be numbers');");
			out.println("window.location.href='players.jsp';");
			out.println("</script>");
		}		
	}
}
