package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddStaff
 */
public class AddStaff extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String staffid=request.getParameter("staffid");
		String name=request.getParameter("name");
		String salary=request.getParameter("salary");
		String dob=request.getParameter("dob");
		String contact=request.getParameter("contact");
		String address=request.getParameter("address");
		String type=request.getParameter("type");
		String cosp=request.getParameter("cosp");
		String join=request.getParameter("join");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			String sql = "insert into staff values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, staffid);
			ps.setString(2, name);
			ps.setString(3, salary);
			ps.setString(4, dob);
			ps.setString(5, contact);
			ps.setString(6, address);
			ps.setString(7, type);
			ps.setString(8, cosp);
			ps.setString(9, join);
			ps.executeUpdate();
			ps.close();
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data inserted in your database');");
			out.println("window.location.href='staff.jsp';");
			out.println("</script>");
			con.close();
			}
		catch(Exception e) {
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data not inserted: staff id may exist , salary and contact should be numbers');");
			out.println("window.location.href='staff.jsp';");
			out.println("</script>");
		}
	}

}
