package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddPrize
 */
public class AddPrize extends HttpServlet {
	private static final long serialVersionUID = 1L;
     	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     		String date=request.getParameter("date");
    		String title=request.getParameter("title");
    		String playerid=request.getParameter("playerid");
    		String playername=request.getParameter("playername");
    		String sportname=request.getParameter("sportname");
    		String pos=request.getParameter("pos");
    		String team_ind=request.getParameter("team-ind");
    		response.setContentType("text/html");
    		PrintWriter out = response.getWriter();
    		
    		try {
    			Class.forName("com.mysql.cj.jdbc.Driver");
    			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
    			String sql = "insert into prizes values(?,?,?,?,?,?,?)";
    			PreparedStatement ps = con.prepareStatement(sql);
    			ps.setString(1, date);
    			ps.setString(2, title);
    			ps.setString(3, playerid);
    			ps.setString(4, playername);
    			ps.setString(5, sportname);
    			ps.setString(6, pos);
    			ps.setString(7, team_ind);
    			ps.executeUpdate();
    			ps.close();
    			out.println("<script type=\"text/javascript\">");
    			out.println("window.alert('Data inserted in your database');");
    			out.println("window.location.href='prizes.jsp';");
    			out.println("</script>");
    			con.close();
    			}
    		catch(Exception e) {
    			out.println("<script type=\"text/javascript\">");
    			out.println("window.alert('Data not inserted: position should be number');");
    			out.println("window.location.href='prizes.jsp';");
    			out.println("</script>");
    		}
		
     	}
}
