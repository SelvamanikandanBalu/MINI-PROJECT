package selva;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class DelUser
 */
public class DelUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("username");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			if(!con.isClosed()){
				PreparedStatement ps = con.prepareStatement("select * from login where uname = ?");
				ps.setString(1, uname);
				ResultSet rs=ps.executeQuery();
			    if(rs.next()) {
			String sql = "delete from login where uname = ?";
			PreparedStatement pse = con.prepareStatement(sql);
			pse.setString(1, uname);
			pse.executeUpdate();
			pse.close();
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data removed');");
			out.println("window.location.href='users.jsp';");
			out.println("</script>");
			con.close();
			    }else {
			    	out.println("<script type=\"text/javascript\">");
					out.println("window.alert('Data not removed: the given value may does not exist');");
					out.println("window.location.href='users.jsp';");
					out.println("</script>");
			    }
				}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
