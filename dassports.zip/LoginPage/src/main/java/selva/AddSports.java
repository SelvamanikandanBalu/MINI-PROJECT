package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddSports
 */
public class AddSports extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sports=request.getParameter("sports");
		String name=request.getParameter("name");
		String fees=request.getParameter("fee");
		String time=request.getParameter("time");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			String sql = "insert into sports values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, sports);
			ps.setString(2, name);
			ps.setString(3, fees);
			ps.setString(4, time);
			ps.executeUpdate();
			ps.close();
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data inserted in your database');");
			out.println("window.location.href='sports.jsp';");
			out.println("</script>");
			con.close();
			}
		catch(Exception e) {
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data not inserted: infrastructure id may exist , cost and quantity should be numbers');");
			out.println("window.location.href='sports.jsp';");
			out.println("</script>");
		}
	}

}
