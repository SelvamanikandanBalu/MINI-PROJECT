package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DelInfra
 */
public class DelInfra extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String infras=request.getParameter("infrastructure");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			if(!con.isClosed()){
			PreparedStatement ps = con.prepareStatement("select * from infra where Infrastructure_id = ?");
			ps.setString(1, infras);
			ResultSet rs=ps.executeQuery();
		    if(rs.next()) {
		    	String sql = "delete from infra where Infrastructure_id = ?";
			    PreparedStatement pse = con.prepareStatement(sql);
			    pse.setString(1, infras);
			    pse.executeUpdate();
			    pse.close();
			    out.println("<script type=\"text/javascript\">");
			    out.println("window.alert('Data removed');");
			    out.println("window.location.href='infra.jsp#sectionIds';");
			    out.println("</script>");
			    con.close();
		    }else {
				out.println("<script type=\"text/javascript\">");
				out.println("window.alert('Data not removed: the given value may does not exist');");
				out.println("window.location.href='infra.jsp#sectionIds';");
				out.println("</script>");
		    }
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
