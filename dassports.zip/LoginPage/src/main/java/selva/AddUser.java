package selva;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class AddUser
 */
public class AddUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		String uname=request.getParameter("uname");
    		String pass=request.getParameter("password");
    		response.setContentType("text/html");
    		PrintWriter out = response.getWriter();
    		
    		try {
    			Class.forName("com.mysql.cj.jdbc.Driver");
    			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
    			String sql = "insert into login values(?,?)";
    			PreparedStatement ps = con.prepareStatement(sql);
    			ps.setString(1, uname);
    			ps.setString(2, pass);
    			ps.executeUpdate();
    			ps.close();
    			out.println("<script type=\"text/javascript\">");
    			out.println("window.alert('Data inserted in your database');");
    			out.println("window.location.href='users.jsp';");
    			out.println("</script>");
    			con.close();
    			}
    		catch(Exception e) {
    			out.println("<script type=\"text/javascript\">");
    			out.println("window.alert('Data not inserted: user id may exist');");
    			out.println("window.location.href='users.jsp';");
    			out.println("</script>");
    		}
	}

}
