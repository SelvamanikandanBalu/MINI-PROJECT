package selva;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddInfra
 */
public class AddInfra extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String infra=request.getParameter("infrastructure");
		String name=request.getParameter("name");
		String cost=request.getParameter("cost");
		String type=request.getParameter("type");
		String quantity=request.getParameter("quantity");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/selva","root","Selvam@2004");
			String sql = "insert into infra values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, infra);
			ps.setString(2, name);
			ps.setString(3, cost);
			ps.setString(4, type);
			ps.setString(5, quantity);
			ps.executeUpdate();
			ps.close();
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data inserted in your database');");
			out.println("window.location.href='infra.jsp#sectionId';");
			out.println("</script>");
			con.close();
			}
		catch(Exception e) {
			out.println("<script type=\"text/javascript\">");
			out.println("window.alert('Data not inserted: sports id may exist , fee should be numbers');");
			out.println("window.location.href='infra.jsp#sectionId';");
			out.println("</script>");
		}
	}

}
